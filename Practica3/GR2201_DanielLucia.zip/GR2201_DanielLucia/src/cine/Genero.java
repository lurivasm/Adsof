package cine;

/**
 * Enumeracion Genero
 * @author Lucia Rivas Molina <lucia.rivasmolina@estudiante.uam.es>
 * @author Daniel Santo-Tomas Lopez <daniel.santo-tomas@estudiante.uam.es>
 *
 */
public enum Genero {
	ACCION, COMEDIA, DRAMA, FANTASIA, ROMANCE, SUSPENSE, TERROR, WESTERN
}
